import numpy as np
temperature = np.array([253.0698, 253.6229, 252.1977, 253.7464,253.2619,
              253.4597,252.7106, 253.0059, 252.1351,253.0936,
              252.0229],np.float32)
print temperature.mean()
