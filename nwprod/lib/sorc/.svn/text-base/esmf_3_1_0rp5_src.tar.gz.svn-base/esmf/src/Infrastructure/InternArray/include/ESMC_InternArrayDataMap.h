// $Id: ESMC_InternArrayDataMap.h,v 1.1 2006/03/24 16:33:28 theurich Exp $
//
//-------------------------------------------------------------------------
//BOP
//
// !CLASS: ESMC_DataMap

// !PUBLIC MEMBER FUNCTIONS:

// !INTERFACE:
//  void ESMC_DataMapValidate(ESMC_DataMap *datamap, int *rc);
//   // Routine to validate the internal state of an datamap object.
//   // !REQUIREMENTS:  FLD4.1
//   //
//   //
// !INTERFACE:
//  void ESMC_DataMapPrint(ESMC_DataMap *datamap, char *options, int *rc);
//   // Routine to print information about an datamap object.
//   // !REQUIREMENTS:
//   //
//   //
//EOP
//

